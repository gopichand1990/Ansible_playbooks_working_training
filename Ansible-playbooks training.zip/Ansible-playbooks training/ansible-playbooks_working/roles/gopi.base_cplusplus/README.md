=========

base_cplusplusis a role that installs C++ compiler tools

Requirements
------------

RHEL-like system, or Ubuntu


Role Variables
--------------
The vars hardly need a change.
cplusplusrpms, cplusplusapts


Dependencies
------------

none

Example Usage
----------------

Refer to a complete build server https://github.com/bbaassssiiee/buildserver

License
-------

MIT

Author Information
------------------

Bas Meijer
@bbaassssiiee
